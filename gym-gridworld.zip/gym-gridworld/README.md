**Status:** Beta version (code has been quickly adapted from OpenAI Gym - FrozenLake)

# gym-gridworld

The GridWorld adapts the FrozenLake environment to replicate the minimalistic GridWorld used in Chapter 4 of the book Reinforcement Learning: an Introduction.

# Installation

```bash
git clone https://github.com/andremht/gym-gridworld.git
cd gym-gridworld
pip install -e .
```
