from gym_RLcourse.envs.corridor_env import CorridorEnv
from gym_RLcourse.envs.shortCorridor_env import ShortCorridorEnv
from gym_RLcourse.envs.dynaMaze_env import DynaMazeEnv

